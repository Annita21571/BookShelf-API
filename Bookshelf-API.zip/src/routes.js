const {
  AddBook,
  GetAllBook,
  GetBook,
  UpdateBook,
  DeleteBook,
} = require('./handler');

const routes = [
  {
    method: 'POST',
    path: '/books',
    handler: AddBook,
  },
  {
    method: 'GET',
    path: '/books',
    handler: GetAllBook,
  },
  {
    method: 'GET',
    path: '/books/{bookId}',
    handler: GetBook,
  },
  {
    method: 'PUT',
    path: '/books/{bookId}',
    handler: UpdateBook,
  },
  {
    method: 'DELETE',
    path: '/books/{bookId}',
    handler: DeleteBook,
  },
];

module.exports = routes;
